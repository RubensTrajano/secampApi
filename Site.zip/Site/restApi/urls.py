
from django.contrib import admin
from django.urls import path


from django.contrib import admin
from django.urls import path, include

from restApiModels.urls import routerrestApiModels

urlpatterns = [
    path('admin/', admin.site.urls),


    path(r'professor', include(routerrestApiModels.urls))
]
