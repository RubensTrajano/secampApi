from rest_framework import serializers
from .models import *

class ProfessoresSerializer(serializers.ModelSerializer):
    class Meta:
        model = Professores
        fields = '__all__'
