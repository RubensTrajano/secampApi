from rest_framework import routers
from .views import *

routerrestApiModels = routers.DefaultRouter()
routerrestApiModels.register('professor', ProfessoresView)
